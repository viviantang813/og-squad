"""YHack Project"""

from math import ceil  

class Constants:
    """
    A collection of game-specific constants.
    
    """
    # width and height of keepers
    KEEPER_WIDTH = 31
    KEEPER_HEIGHT = 31

    # width and height of animals
    ANIMAL_WIDTH = 31
    ANIMAL_HEIGHT = 31

    # width and height of food
    FOOD_WIDTH = 11
    FOOD_HEIGHT = 11

    # width and height of rocks
    ROCK_WIDTH = 51
    ROCK_HEIGHT = 51

    # thickness of the path
    PATH_THICKNESS = 31

    # some other characters
    DEMON_WIDTH = 51
    DEMON_HEIGHT = 51
    DEMON_RADIUS = 75  # Only animals this close are affected.
    DEMON_MULTIPLIER = 2  # Animal speeds multiplied by this factor
    DEMON_PRICE = 100

    VHS_WIDTH = 31
    VHS_HEIGHT = 31
    VHS_RADIUS = 75
    VHS_MULTIPLIER = .5
    VHS_PRICE = 20

    RABBIT_WIDTH = 75 #new implemented feature
    RABBIT_HEIGHT = 75
    RABBIT_RADIUS = 100
    RABBIT_MULTIPLIER = 10
    RABBIT_PRICE = 250

    CRAZY_NAP_LENGTH = 20

    TRAINEE_THRESHOLD = 20  # How many food hits must the trainee score,
    # before becoming a speedy zookeeper?

    TEXTURES = {
        'rock': '1f5ff',
        'animal': '1f418',
        'SpeedyZookeeper': '1f472',
        'ThriftyZookeeper': '1f46e',
        'OverreachingZookeeper': '1f477',
        'food': '1f34e',
        'Demon': '1f479',
        'VHS': '1f4fc',
        'TraineeZookeeper': '1f476',
        'CrazyZookeeper': '1f61c',
        'SleepingZookeeper': '1f634', 
        'Rabbit': '1f407' #new implemented feature
    }

    KEEPER_INFO = {'SpeedyZookeeper':
                       {'price': 250,
                        'range': 50,
                        'throw_speed_mag': 20},
                   'ThriftyZookeeper':
                       {'price': 100,
                        'range': 100,
                        'throw_speed_mag': 15},
                   'OverreachingZookeeper':
                       {'price': 150,
                        'range': 150,
                        'throw_speed_mag': 5},
                   'TraineeZookeeper':
                       {'price': 50,
                        'range': 100,
                        'throw_speed_mag': 5},
                   'CrazyZookeeper':
                       {'price': 100,
                        'range': 1000,
                        'throw_speed_mag': 50}
                   }


class NotEnoughMoneyError(Exception):
    """A custom exception to be used when insufficient funds are available
    to hire new zookeepers."""
    pass



################################################################################
################################################################################
# Static methods.

def distance(a, b):
    """Returns the Euclidian distance between the two tuple coordinates."""
    return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** 0.5



################################################################################
################################################################################

class Game:
    def __init__(self, game_info):
        """Initializes the game.

        `game_info` is a dictionary formatted in the following manner:
          { 'width': The width of the game grid, in an integer (i.e. number of pixels).
            'height': The height of the game grid, in an integer (i.e. number of pixels).
            'rocks': The set of tuple rock coordinates.
            'path_corners': An ordered list of coordinate tuples. The first
                            coordinate is the starting point of the path, the
                            last point is the end point (both of which lie on
                            the edges of the gameboard), and the other points
                            are corner ("turning") points on the path.
            'money': The money balance with which the player begins.
            'spawn_interval': The interval (in timesteps) for spawning animals
                              to the game.
            'animal_speed': The magnitude of the speed at which the animals move
                            along the path, in units of grid distance traversed
                            per timestep.
            'num_allowed_unfed': The number of animals allowed to finish the
                                 path unfed before the player loses.
          }
        """
        self.width = game_info['width']
        self.height = game_info['height']
        self.money = game_info['money']
        self.spawn_interval = game_info['spawn_interval']
        self.animal_speed = game_info['animal_speed']
        self.num_allowed_unfed = game_info['num_allowed_unfed']

        self.rocks = set()
        for rock in game_info['rocks']: #create instances of Formation class for each rock
            self.rocks.add(Formations(rock, rock, 1, 'rock'))
        self.animals = [] #initialized as list, in order of travel along pathway
        self.zookeepers = set()
        self.food = set()

        self.food_trainee = dict()
        
        self.demons = set()
        self.vhs = set()
        self.rabbits = set()

        #initialize the path as a list
        self.path_corners = game_info['path_corners']
        self.path = [] #list of the center of the path for the entire path
        #edges of the paths can be found by finding points that are:
            #Constants.PATH_THICKNESS//2 away from each of the elements in the coordinates
            #not in the path
        for i in range(0, len(self.path_corners)-1):
            if self.path_corners[i][0] == self.path_corners[i+1][0]:
                #if the x coordinates are the same so traveling vertically
                if self.path_corners[i+1][1] - self.path_corners[i][1] < 0:
                    step = -1
                else:
                    step = 1
                for j in range(self.path_corners[i][1], self.path_corners[i+1][1], step):
                    self.path.append((self.path_corners[i][0],j))
            elif self.path_corners[i][1] == self.path_corners[i+1][1]:
                #if the y coordinates are the same so traveling horizontally
                if self.path_corners[i+1][0] - self.path_corners[i][0] < 0:
                    step = -1
                else:
                    step = 1
                for j in range(self.path_corners[i][0], self.path_corners[i+1][0], step):
                    self.path.append((j,self.path_corners[i][1]))
        
        self.status = 'ongoing'
        self.money_left = self.money
        self.num_allowed_remaining = self.num_allowed_unfed

        self.current_clicked = None

        self.time = 0

        self.demon_multiplier = Constants.DEMON_MULTIPLIER
        self.vhs_multiplier = Constants.VHS_MULTIPLIER
        self.rabbit_multiplier = Constants.RABBIT_MULTIPLIER



    def render(self):
        """Renders the game in a form that can be parsed by the UI.

        Returns a dictionary of the following form:
          { 'formations': A list of dictionaries in any order, each one
                          representing a formation. Each dictionary is of the form
                            `{'loc': (x, y),
                              'texture': texture,
                              'size': (width, height)}`
                          where `(x,y)` is the center coordinate of the formation,
                          `texture` is its texture, and it has `width` and `height`
                          dimensions. The dictionary should contain the
                          formations of all animals, zookeepers, rocks, and food.
            'money': The amount of money the player has available.
            'status': The current state of the game which can be 'ongoing' or 'defeat'.
            'num_allowed_remaining': The number of animals which are still
                                     allowed to exit the board before the game
                                     status is `'defeat'`.
          }
        """
        output = {'formations': [], 'money': self.money_left, 'status': self.status,
                  'num_allowed_remaining': self.num_allowed_remaining}

        for el in set(self.rocks).union(self.zookeepers, self.animals, self.food, self.demons, self.vhs):
            temp = {'loc': (el.x, el.y), 'texture': el.texture_key, 'size': (el.width, el.height)}
            output['formations'].append(temp)

        return output



    ################################################################################
    #HELPER FUNCTIONS FOR TIMESTEP


    #functions 

    def update_loc_food(self, food):
        #updates location of food item based on its velocity (calculated from direction, speed in Formations class)
        food.x += food.vx
        food.y += food.vy


    def find_coord_in_path(self, animal):
        #returns the index of the coordinate in the path that the animal is at
        for i in range(len(self.path)):
            animal_formation = self.animals[animal]
            if self.path[i] == (animal_formation.x, animal_formation.y):
                return i
        return None


    def update_loc_animal(self, animal):
        #updates location of animal based on its speed and the path
        animal_index = self.animals.index(animal)
        animal_index = self.find_coord_in_path(animal_index)
        try:
            new_loc = self.path[animal_index + animal.speed]
            animal.x, animal.y = new_loc
        except:
            if self.path_corners[-1][0] == self.path_corners[-2][0]:
                animal.y += animal.speed
            if self.path_corners[-1][1] == self.path_corners[-2][1]:
                animal.x += animal.speed


    def off_board(self, thing):
        #returns True if thing is off of the game board and returns True if it's on the game board
        if (thing.x < 0 or thing.x > self.width) or (thing.y < 0 or thing.y > self.height):
            return True
        else: return False


    def remove_food(self, food):
        #removes the food from the board by removing the instance of the class
        self.food.remove(food) #remove from the set of foods


    def remove_animal(self, animal):
        #removes the animal from the board by removing the instance of the class
        self.animals.remove(animal) #remove from the set of animals



    #functions 

    def in_range(self, item, animal):
        #returns True if an animal is within the item's range, returns False if not
        if distance((item.x, item.y), (animal.x, animal.y)) <= item.radius:
            return True
        else: return False


    def find_aim_animal(self, zookeeper):
        #returns the index of the animal furthest along the path within range of the zookeeper
        for i in range(len(self.animals)):
            if self.in_range(zookeeper, self.animals[i]):
                return i


    #helper functions for find_aim
    def food_time_until_coord(self, keeper, coord):
        #returns the time it will take for a food to travel from the keeper to a given coord
        dist = distance((keeper.x,keeper.y), coord)
        time = dist/keeper.speed
        return time


    def animal_time_until_coord(self, animal, coord):
        #returns the time it will take for an animal to travel from current location to a given coord
        animal_formation = self.animals[animal]
        current_loc_index = self.path.index((animal_formation.x, animal_formation.y))
        coord_index = self.path.index(coord)
        distance = coord_index - current_loc_index #how many points along path to travel
        time = distance/animal_formation.speed
        return time


    def find_aim(self, keeper, aim_animal):
        #returns the coordinate in the path where the food should be aimed according to the algorithm described above
        next_coord_index = self.find_coord_in_path(aim_animal) + 1
        if next_coord_index != None:
            time_coord = float('inf')
            output_coord = None
            for coord in self.path[next_coord_index:]:
                food_time_until_coord = self.food_time_until_coord(keeper, coord)
                animal_time_until_coord = self.animal_time_until_coord(aim_animal, coord)
                if abs(food_time_until_coord - animal_time_until_coord) < time_coord:
                    time_coord = abs(food_time_until_coord - animal_time_until_coord)
                    output_coord = coord
        else:
            output_coord = self.path[-1]
        return output_coord


    #helper functions for crazy/sleeping zookeeper
    def sleep(self, keeper):
        #helper function to turn a crazy zookeeper into a sleeping zookeeper
        self.zookeepers.add(Formations((keeper.x, keeper.y), (keeper.x, keeper.y), 0, 'SleepingZookeeper'))
        self.zookeepers.remove(keeper)


    def wake(self, keeper):
        #helper function to turn a sleeping zookeeper into a crazy zookeeper
        self.zookeepers.add(Formations((keeper.x, keeper.y), (keeper.x, keeper.y), 0, 'CrazyZookeeper'))
        self.zookeepers.remove(keeper)


    #functions

    def can_place(self, item):
        #returns False if there is a collision with the proposed item location item
        #compares to locations of rocks and other items and the path
        for formation in self.rocks.union(self.zookeepers, self.demons, self.vhs, self.rabbits):
            if item.collision(formation):
                return False
        return all(distance((item.x, item.y), coord) >= Constants.PATH_THICKNESS for coord in self.path)



    #END OF HELPER FUNCTIONS FOR TIMESTEP
    ################################################################################


    def timestep(self, mouse=None):
        """Simulates the evolution of the game by one timestep.
        """
        if self.status == 'ongoing': #if the state of the game is ongoing
            #1: for each demon or VHS, if in range, multiply animal speed by the multiplier
            for animal in self.animals:
                num_demons = 0
                num_vhs = 0
                num_rabbits = 0 #new implemented feature
                for demon in self.demons:
                    if self.in_range(demon, animal):
                        num_demons += 1
                for vhs in self.vhs:
                    if self.in_range(vhs, animal):
                        num_vhs += 1
                for rabbit in self.rabbits:
                    if self.in_rangee(rabbit, animal):
                        num_rabbits += 1
                animal.speed = ceil(self.animal_speed * self.demon_multiplier**num_demons * self.vhs_multiplier**num_vhs * self.rabbit_multiplier**num_rabbits)


            #2: update_loc function for each formation that moves (food and animal; food straight line of direction, animal along path)
                # - if food center off board (helper function for off board), remove
                # - if animal center off board, remove and subtract one from num_allowed_remaining
            for food in self.food:
                self.update_loc_food(food)
            for animal in self.animals:
                self.update_loc_animal(animal)
            for food in self.food.copy():
                if self.off_board(food):
                    self.remove_food(food)
            for animal in self.animals.copy():
                if self.off_board(animal):
                    self.remove_animal(animal)
                    self.num_allowed_remaining -= 1
                

            #3: using Formations collision function
                #for each animal:
                    #for each food, if collide with animal, remove food, change a marker to say something was removed
                    #if marker says something was removed, remove animal, add one to count_fed
            count_fed = 0
            for animal in self.animals.copy():
                temp = 0
                for food in self.food.copy():
                    if animal.collision(food):
                        if food in self.food_trainee: #update practice count for food thrown by trainees
                            self.food_trainee[food].practice += 1
                            self.food_trainee.pop(food)
                        self.remove_food(food)
                        temp = 1
                if temp == 1:
                    count_fed += 1
                    self.remove_animal(animal)


            #4: NEW HERE: Upgrade trainee zookeeper if needed.
            for keeper in self.zookeepers:
                if keeper.texture == 'TraineeZookeeper':
                    if keeper.practice >= Constants.TRAINEE_THRESHOLD: #ready to upgrade zookeeper
                        self.zookeepers.add(Formations((keeper.x, keeper.y), (keeper.x, keeper.y), 0, 'SpeedyZookeeper'))
                        self.zookeepers.remove(keeper)


            #5: for each zookeeper,
                # - helper function to determine if in range (distance <= b/c can lie on edge)
                # - create a food formation directed at the animal aim_animal furthest along path
                    #helper function to aim the food at aim_animal
                        # - for every coord in path:
                            # - if aim_animal already passed point then disregard
                            # - compute how long (number timesteps) before center of aim_animal reaches coord at velocity
                            # - compute how long (number timesteps) before the center of food launched in the direction of coord reaches coord at velocity
                        # - throw food in direction of coord with smallest difference between the times with velocity given by zookeeper
            for keeper in self.zookeepers:
                if keeper.texture != 'SleepingZookeeper':
                    aim_animal = self.find_aim_animal(keeper)
                    if aim_animal != None:
                        coord = self.find_aim(keeper, aim_animal)
                        if coord != None:
                            food = Formations((keeper.x, keeper.y), coord, keeper.speed, 'food')
                            self.food.add(food)
                            if keeper.texture == 'TraineeZookeeper':
                                #an additional condition to keep track of foods thrown by Trainee
                                self.food_trainee[food] = keeper
                else:
                    pass


            #PUT ZOOKEEPER TO SLEEP IF NEEDED
            for keeper in self.zookeepers:
                #for all crazy zookeepers, put them to sleep because they just threw
                if keeper.texture == 'CrazyZookeeper':
                    self.sleep(keeper)

            for keeper in self.zookeepers:
                #for all sleeping zookeepers, wake them up or add one to their nap length
                if keeper.texture == 'SleepingZookeeper':
                    if keeper.nap_length == keeper.nap:
                        self.wake(keeper)
                    else:
                        keeper.nap_length += 1




            #6: create new formation with animal at path start if self.time is multiple of self.spawn_interval


            if self.time % self.spawn_interval == 0:
                self.animals.append(Formations(self.path[0], self.path[1], self.animal_speed, 'animal'))


            #7: if mouse not None, create formation with the keeper in the location
                #have a stored variable for the type of keeper (if type(mouse)==string), else do the following
                #create helper function that makes sure that
                    # - self.money_left > cost of keeper (else raise NotEnoughMoneyError)
                    # - no collisions with path or other zookeepers and rocks
                    # - if none of these, then add to self.zookeepers
            if mouse != None:
                if type(mouse) == str:
                    self.current_clicked = mouse
                else:
                    if self.current_clicked == 'Demon':
                        demon = Formations(mouse, mouse, 0, self.current_clicked)
                        if self.money_left >= demon.price:
                            if self.can_place(demon):
                                self.demons.add(demon)
                                self.money_left -= demon.price
                            else:
                                pass
                        else:
                            raise NotEnoughMoneyError
                    if self.current_clicked == 'VHS':
                        VHS = Formations(mouse, mouse, 0, self.current_clicked)
                        if self.money_left >= VHS.price:
                            if self.can_place(VHS):
                                self.vhs.add(VHS)
                                self.money_left -= VHS.price
                            else:
                                pass
                        else:
                            raise 
                    if self.current_clicked == 'Rabbit':
                        rabbit = Formations(mouse, mouse, 0, self.current_clicked)
                        if self.money_left >= rabbit.price:
                            if self.can_place(rabbit):
                                self.rabbit.add(rabbit)
                                self.money_left -= rabbit.price
                            else:
                                pass
                        else:
                            raise NotEnoughMoneyError
                    if self.current_clicked in {'SpeedyZookeeper', 'ThriftyZookeeper', 'OverreachingZookeeper', 'TraineeZookeeper', 'CrazyZookeeper', 'SleepingZookeeper'}:
                        keeper = Formations(mouse, mouse, 0, self.current_clicked)
                        if self.money_left >= keeper.price:
                            if self.can_place(keeper):
                                self.zookeepers.add(keeper)
                                self.money_left -= keeper.price
                            else:
                                pass
                        else:
                            raise NotEnoughMoneyError


            #8: add count_fed to money_left, count_fed = 0

            self.money_left += count_fed
            count_fed = 0


            #9: check self.num_allowed_remaining, if it gets to <0, self.status = 'defeat'


            if self.num_allowed_remaining < 0:
                self.status = 'defeat'


            self.time += 1

        else: #if the state of the game is defeat, do nothing
            pass



################################################################################
################################################################################

class Formations:
    def __init__(self, position, direction, speed, texture):
        self.x = position[0] #center of formation
        self.y = position[1]
        self.speed = speed
        self.texture = texture #string for texture
        self.texture_key = Constants.TEXTURES[texture] #key for texture from Constants class

        if self.texture == 'food':
            #movement of food formation per timestep in x and y dirs
            #total magnitude of vx and vy is speed
            #vx and vy go in the direction of self.direction
            self.vx = (direction[0] - position[0]) * (speed / distance(direction, position))
            self.vy = (direction[1] - position[1]) * (speed / distance(direction, position))

        if self.texture == 'Demon':
            self.width = Constants.DEMON_WIDTH
            self.height = Constants.DEMON_HEIGHT
            self.radius = Constants.DEMON_RADIUS
            self.price = Constants.DEMON_PRICE

        if self.texture == 'VHS':
            self.width = Constants.VHS_WIDTH
            self.height = Constants.VHS_HEIGHT
            self.radius = Constants.VHS_RADIUS
            self.price = Constants.VHS_PRICE

        if self.texture == 'Rabbit': #new implemented feature
            self.width = Constants.RABBIT_WIDTH
            self.height = Constants.RABBIT_HEIGHT
            self.radius = Constants.RABBIT_RADIUS
            self.price = Constants.RABBIT_PRICE

        #initialize the widths and heights of the formation, different for each texture
        if self.texture in {'SpeedyZookeeper', 'ThriftyZookeeper', 'OverreachingZookeeper', 'TraineeZookeeper', 'CrazyZookeeper', 'SleepingZookeeper'}:
            self.width = Constants.KEEPER_WIDTH
            self.height = Constants.KEEPER_HEIGHT
        if self.texture == 'animal':
            self.width = Constants.ANIMAL_WIDTH
            self.height = Constants.ANIMAL_HEIGHT
        if self.texture == 'food':
            self.width = Constants.FOOD_WIDTH
            self.height = Constants.FOOD_HEIGHT
        if self.texture == 'rock':
            self.width = Constants.ROCK_WIDTH
            self.height = Constants.ROCK_HEIGHT

        #initialize a tracker for the trainee zookeeper
        if self.texture == 'TraineeZookeeper':
            self.practice = 0

        #initialize a tracker for the sleeping zookeeper
        if self.texture == 'SleepingZookeeper':
            self.nap = Constants.CRAZY_NAP_LENGTH
            self.nap_length = 0

        #store info on keeper if texture is a zookeeper
        if self.texture in {'SpeedyZookeeper', 'ThriftyZookeeper', 'OverreachingZookeeper', 'TraineeZookeeper', 'CrazyZookeeper'}:
            self.keeper_info = Constants.KEEPER_INFO[self.texture]
            self.price = self.keeper_info['price']
            self.radius = self.keeper_info['range']
            self.speed = self.keeper_info['throw_speed_mag']


    def collision(self, other):
        #returns True if there is a collision between formations self and other
        #returns False is there is no collision (edges don't count)
        start_x = self.x - self.width/2
        end_x = self.x + self.width/2
        start_y = self.y - self.height/2
        end_y = self.y + self.height/2

        x_0 = other.x - other.width/2
        x_1 = other.x + other.width/2
        y_0 = other.y - other.height/2
        y_1 = other.y + other.height/2

        if (start_x < x_0 and x_0 < end_x) or (start_x < x_1 and x_1 < end_x) or (start_x < x_0 and x_1 < end_x) or (start_x > x_0 and x_1 > end_x):
            if (start_y < y_0 and y_0 < end_y) or (start_y < y_1 and y_1 < end_y) or (start_y < y_0 and y_1 < end_y) or (start_y > y_0 and y_1 > end_y):
                return True
        elif start_x == x_0 and end_x == x_1:
            if start_y == y_0 and end_y == y_1:
                return True
        else:
            return False

if __name__ == '__main__':
    pass
